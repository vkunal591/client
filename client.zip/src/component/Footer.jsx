import React, { useState } from "react";
import faceboook from "./img/facebook-f.svg";
import instagram from "./img/instagram.svg";
import youtube from "./img/youtube.svg";
import twitter from "./img/twitter.svg";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faUserGroup,
  faEyeLowVision,
  faBrain
} from "@fortawesome/free-solid-svg-icons";

export default function Footer() {
  const [latestnews, setLatestnews] = useState("News");

  return (
    <>
      <nav
        class="navbar bg-dark border-bottom border-body tertiary px-5"
        data-bs-theme="dark"
        style={{ height: "100px" }}
      >
        <div className=" " style={{ color: "whitesmoke" }}>
          Copyright © 2023. All rights reserved. @ymwsolution
        </div>
        <div class="d-flex" style={{ width: "200px",backgroundColor:"whitesmoke" }}>
          <a class="navbar-brand" href="/">
            <img src={faceboook} alt="facebook" style={{ height: "25px" }} />
          </a>
          <a class="navbar-brand" href="/">
            <img src={twitter} alt="facebook" style={{ height: "25px" }} />
          </a>
          <a class="navbar-brand" href="/">
            <img src={youtube} alt="facebook" style={{ height: "25px" }} />
          </a>
          <a class="navbar-brand" href="/">
            <img src={instagram} alt="facebook" style={{ height: "25px" }} />
          </a>
        </div>
      </nav>
    </>
  );
}
