import React from "react";
import Subblog from "./Subblog";
import Sidebar from "./Sidebar";

export default function Latestnews() {
  return (
    <>
      <Sidebar />
      <div className=" mt-3" style={{ marginLeft: "5rem",marginBottom:"1rem", width: "63%" }}>
        <div className="mb-3" style={{ borderBottom: "2px solid skyblue", width: "100%" }}>
          <div
            style={{
              display: "inline-block",
              backgroundColor: "skyblue",
              color: "white",
              width: "110px",
              height: "35px",
              fontSize: "17px",
              textAlign: "center",
              paddingTop: "5px"
            }}
          >
            Categories
          </div>
        </div>
        
        <Subblog />
        <Subblog />
        <Subblog />
        <Subblog />
        <Subblog />
        <Subblog />
        <Subblog />
      </div>
    </>
  );
}
