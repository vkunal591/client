import React from "react";
import Categorypost from "./Categorypost";
import Slidebox from "./Slidebox";
import Sidebar from "./Sidebar";

export default function Home() {
  return (
    <>
      <Slidebox />
      <Sidebar />
      <Categorypost />

      <Categorypost />
      <Categorypost />
      <Categorypost />
    </>
  );
}
