import React from "react";

export default function Services() {
  return (
    <>
      <div className=" mx-auto " style={{ width: "60%" }}>
        <div className="" style={{ textAlign: "center" }}>
          <h3 className="mt-3">Services</h3>
          <p className="my-4" style={{ color: "red" }}>
            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Vitae,
            excepturi maxime accusamus nulla sunt perspiciatis! Maiores ab ipsam
            rem at dolore odio, quod dicta ex itaque labore dolorum nobis
            recusandae.
          </p>
        </div>
        <hr />
        <div className="" style={{}}>
          <h2 className="my-5" style={{ textAlign: "center", color:"darkgreen" }}>Our Services</h2>
          <hr />
          <div class="card-group mt-4" style={{ borderRadius: "0px" }}>
            <div class="card" style={{ borderRadius: "0px" }}>
              <ul
                class="list-group list-group-flush"
                style={{ textAlign: "center" }}
              >
                <li
                  class="list-group-item"
                  style={{
                    borderBottom: "1px solid black",
                    color: "red",
                    fontWeight:"600",
                    height: "55px"
                  }}
                >
                  An item
                </li>
                <li
                  class="list-group-item"
                  style={{ borderBottom: "1px solid black", color: "darkblue" }}
                >
                  A second item
                </li>
                <li
                  class="list-group-item"
                  style={{ borderBottom: "1px solid black", color: "darkblue" }}
                >
                  A third item
                </li>
                <li
                  class="list-group-item"
                  style={{ borderBottom: "1px solid black", color: "darkblue" }}
                >
                  A fourth item
                </li>
                <li
                  class="list-group-item"
                  style={{ borderBottom: "1px solid black", color: "darkblue" }}
                >
                  And a fifth one
                </li>
                <li
                  class="list-group-item"
                  style={{ borderBottom: "1px solid black", color: "darkblue" }}
                >
                  A third item
                </li>
                <li
                  class="list-group-item"
                  style={{ borderBottom: "1px solid black", color: "darkblue" }}
                >
                  A fourth item
                </li>
                <li
                  class="list-group-item"
                  style={{ borderBottom: "1px solid black", color: "darkblue" }}
                >
                  And a fifth one
                </li>
              </ul>
            </div>
            <div class="card" style={{ borderRadius: "0px" }}>
              {" "}
              <ul
                class="list-group list-group-flush"
                style={{ textAlign: "center" }}
              >
                <li
                  class="list-group-item"
                  style={{
                    borderBottom: "1px solid black",
                    color: "red",
                    fontWeight:"600",
                    height: "55px"
                  }}
                >
                  An item
                </li>
                <li
                  class="list-group-item"
                  style={{ borderBottom: "1px solid black", color: "darkblue" }}
                >
                  A second item
                </li>
                <li
                  class="list-group-item"
                  style={{ borderBottom: "1px solid black", color: "darkblue" }}
                >
                  A third item
                </li>
                <li
                  class="list-group-item"
                  style={{ borderBottom: "1px solid black", color: "darkblue" }}
                >
                  A fourth item
                </li>
                <li
                  class="list-group-item"
                  style={{ borderBottom: "1px solid black", color: "darkblue" }}
                >
                  And a fifth one
                </li>
                <li
                  class="list-group-item"
                  style={{ borderBottom: "1px solid black", color: "darkblue" }}
                >
                  A third item
                </li>
                <li
                  class="list-group-item"
                  style={{ borderBottom: "1px solid black", color: "darkblue" }}
                >
                  A fourth item
                </li>
                <li
                  class="list-group-item"
                  style={{ borderBottom: "1px solid black", color: "darkblue" }}
                >
                  And a fifth one
                </li>
              </ul>
            </div>
            <div class="card" style={{ borderRadius: "0px" }}>
              <ul
                class="list-group list-group-flush"
                style={{ textAlign: "center" }}
              >
                <li
                  class="list-group-item"
                  style={{
                    borderBottom: "1px solid black",
                    color: "red",
                    fontWeight:"600",
                    height: "55px"
                  }}
                >
                  An item
                </li>
                <li
                  class="list-group-item"
                  style={{ borderBottom: "1px solid black", color: "darkblue" }}
                >
                  A second item
                </li>
                <li
                  class="list-group-item"
                  style={{ borderBottom: "1px solid black", color: "darkblue" }}
                >
                  A third item
                </li>
                <li
                  class="list-group-item"
                  style={{ borderBottom: "1px solid black", color: "darkblue" }}
                >
                  A fourth item
                </li>
                <li
                  class="list-group-item"
                  style={{ borderBottom: "1px solid black", color: "darkblue" }}
                >
                  And a fifth one
                </li>
                <li
                  class="list-group-item"
                  style={{ borderBottom: "1px solid black", color: "darkblue" }}
                >
                  A third item
                </li>
                <li
                  class="list-group-item"
                  style={{ borderBottom: "1px solid black", color: "darkblue" }}
                >
                  A fourth item
                </li>
                <li
                  class="list-group-item"
                  style={{ borderBottom: "1px solid black", color: "darkblue" }}
                >
                  And a fifth one
                </li>
              </ul>
            </div>
            <p className="my-3" style={{ color: "red", textAlign: "center" }}>
              Lorem, ipsum dolor sit amet consectetur adipisicing elit. Vitae,
              excepturi maxime accusamus nulla sunt perspiciatis! Maiores ab
              ipsam rem at dolore odio, quod dicta ex itaque labore dolorum
              nobis recusandae.
            </p>
          </div>
        </div>

        <div className="" style={{}}>
          <hr />
          <h2 className="my-5" style={{ textAlign: "center", color:"darkgreen" }}>Business Consultancy Services</h2>
          <hr />
          <div
            className="d-flex"
            style={{ width: "100%", textAlign: "center" }}
          >
            <div className="mb-5" style={{ width: "50%" ,textAlign: "center",padding:"0rem 1.5rem" }}>
              <li
                class="list-group-item"
                style={{
                  borderBottom: "1px solid black",
                  color: "darkblue",
                  height: "45px"
                }}
              >
                An item
              </li>
              <p className="mt-3" style={{  color: "darkblue",}} >
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis
                fugiat distinctio, eius mollitia illum animi dolorum? Omnis ut
              </p>
              <p className="mt-3" style={{  color: "darkblue",}}> 
                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Minima
                minus est unde doloremque architecto necessitatibus nobis
              </p>
              <p className="mt-3" style={{  color: "darkblue",}}>
                Lorem ipsum dolor sit amet consectetur adipisicing elit.
                Accusamus magnam temporibus quibusdam veniam enim veritatis
              </p>
            </div>
            <div className="mb-5" style={{ width: "50%", textAlign: "center",padding:"0rem 1.5rem"}}>
              <li
                class="list-group-item"
                style={{
                  borderBottom: "1px solid black",
                  color: "darkblue",
                  height: "45px"
                }}
              >
                An item
              </li>
              <p className="mt-3" style={{  color: "darkblue",}}>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis
                fugiat distinctio, eius mollitia illum animi dolorum? Omnis ut
              </p>
              <p className="mt-3" style={{  color: "darkblue",}}>
                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Minima
                minus est unde doloremque architecto necessitatibus nobis
              </p>
              <h6 className="mt-3"  style={{  color: "darkblue",}}>
                Lorem ipsum dolor sit <a href="">Contact Now</a>
              </h6>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
