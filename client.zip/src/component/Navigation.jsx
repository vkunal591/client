import React from "react";
import "./css/navigation.css";

export default function Navigation() {
  return (
    <>
      <nav
        class="navbar bg-dark border-bottom border-body"
        data-bs-theme="dark"
      >
        <ul class="nav knav ">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="/">
              HOME
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/latest-news">
              LATEST NEWS
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/blogs">
              BLOGS
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/services">
              SERVICES
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="contact-us">
              CONTACT US
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/about-us">
              ABOUT US
            </a>
          </li>
        </ul>
      </nav>
    </>
  );
}
