import React from "react";
import Mpost from "./Mpost";
import Sidepost from "./Sidepost";



export default function Categorypost() {
  return (
    <>
      <div className=" mt-3" style={{ borderBottom: "2px solid blue", marginLeft:"2.1rem", width:"64%" }}>
        <div
          style={{
            display: "inline-block",
            backgroundColor: "blue",
            color: "white",
            width: "110px",
            height: "35px",
            fontSize: "17px",
            textAlign: "center",
            paddingTop: "5px"
          }}
        >
          Recent Posts
        </div>
      </div>
 
        <div className="d-flex mt-4" style={{marginLeft:"2.3rem", width:"65%"}}>
          <Mpost />
          <Sidepost />
        </div>
       
      {/* </div> */}
    </>
  );
}
