import React from 'react'
import Mslidebox from './Mslidebox'
import Sidecard from './Sidecard'
import "./css/slidebox.css"

export default function Slidebox() {
  return (
    <>
        <div className='d-flex mx-auto slidebox mt-3'>
            <Mslidebox />
            <Sidecard />
        </div>
    
    </>
  )
}
