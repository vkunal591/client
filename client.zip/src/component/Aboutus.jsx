import React from "react";
import logo from "../logo.svg";

export default function Aboutus() {
  return (
    <>
      <div className=" mx-auto mb-5" style={{ width: "65%", textAlign: "center" }}>
        <h4 className="mt-3" style={{ textAlign: "left" }}>
          <span style={{}}>About Us</span>
        </h4>
        <hr className="my-2" />
        <h2 className="mt-3" style={{ textAlign: "left" }}>
          <span style={{}}>Corporate Solution</span>
        </h2>

        <div className="" style={{ textAlign: "center" }}>
          <img
            src={logo}
            alt=""
            className="mx-auto"
            style={{ width: "300px" }}
          />
        </div>
        <p className="mt-3  mx-auto" style={{ width: "85%" }}>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequatur
          similique alias ipsum ab necessitatibus esse eaque? Rem repudiandae
          aspernatur, quas sunt similique, pariatur ex tenetur blanditiis rerum,
          quia dolorum fugit.
        </p>
        <p className="mt-3  mx-auto" style={{ width: "85%" }}>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequatur
          similique alias ipsum ab necessitatibus esse eaque? Rem repudiandae
          aspernatur, quas sunt similique, pariatur ex tenetur blanditiis rerum,
          quia dolorum fugit.
        </p>

    <hr className="my-5" />

        <div className="" style={{ textAlign: "center" }}>
          <img
            src={logo}
            alt=""
            className="mx-auto"
            style={{ width: "300px" }}
          />
        </div>

        <h2 style={{ textAlign: "left" }}>
          <span>Owner Name</span>
        </h2>
        <p className="mt-3  mx-auto" style={{ width: "85%" }}>
          Lorem ipsum dolor sit, amet consectetur adipisicing elit. Earum
          officiis et natus, in ullam molestias. Rem deserunt voluptatibus nobis
          odio harum! Cumque quisquam praesentium at facilis nihil labore dicta
          ipsam.
        </p>
        <p className="mt-3  mx-auto" style={{ width: "85%" }}>
          Lorem ipsum dolor sit, amet consectetur adipisicing elit. Debitis
          consequuntur tenetur quo saepe tempore laboriosam sapiente numquam
          delectus commodi, iste, minus facere maxime necessitatibus doloremque
          atque maiores et neque sit.
        </p>
        <p className="mt-3  mx-auto" style={{ width: "85%" }}>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequatur
          similique alias ipsum ab necessitatibus esse eaque? Rem repudiandae
          aspernatur, quas sunt similique, pariatur ex tenetur blanditiis rerum,
          quia dolorum fugit.
        </p>

    <hr className="my-5" />

        <div className="" style={{ textAlign: "center" }}>
          <img
            src={logo}
            alt=""
            className="mx-auto"
            style={{ width: "300px" }}
          />
        </div>

        <h2 style={{ textAlign: "left" }}>
          <span>Owner Name</span>
        </h2>
        <p className="mt-3  mx-auto" style={{ width: "85%" }}>
          Lorem ipsum dolor sit, amet consectetur adipisicing elit. Earum
          officiis et natus, in ullam molestias. Rem deserunt voluptatibus nobis
          odio harum! Cumque quisquam praesentium at facilis nihil labore dicta
          ipsam.
        </p>
        <p className="mt-3  mx-auto" style={{ width: "85%" }}>
          Lorem ipsum dolor sit, amet consectetur adipisicing elit. Debitis
          consequuntur tenetur quo saepe tempore laboriosam sapiente numquam
          delectus commodi, iste, minus facere maxime necessitatibus doloremque
          atque maiores et neque sit.
        </p>
        <p className="mt-3  mx-auto" style={{ width: "85%" }}>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequatur
          similique alias ipsum ab necessitatibus esse eaque? Rem repudiandae
          aspernatur, quas sunt similique, pariatur ex tenetur blanditiis rerum,
          quia dolorum fugit.
        </p>
      </div>
    </>
  );
}
