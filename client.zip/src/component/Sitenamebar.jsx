import React from "react";

export default function Sitenamebar() {
  return (
    <>
      <nav class="navbar" style={{backgroundColor: "#e3f2fd"}}>
        <a class="navbar-brand" href="#" style={{marginLeft:"3rem"}}>
        <h1>Corporate Solution</h1>
        </a>
      </nav>
    </>
  );
}
