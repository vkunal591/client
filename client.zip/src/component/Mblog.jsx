import React from "react";
import p1 from "./img/p1.jpg";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faCalendar,
  faTag,
  faIndustry
} from "@fortawesome/free-solid-svg-icons";


export default function Mblog() {
  return (
    <>
      <div class="mt-3" style={{ width: "100%" }}>
        <img src={p1} class="card-img-top" alt="..." />

        <div class="">
          <h5 className="ms-3 mt-2">First slide label</h5>
          <p>
            <span className="mx-3">
              <FontAwesomeIcon icon={faCalendar} className="mx-2 icon-color" />
              date
            </span>{" "}
            <span className="mx-3">
              <FontAwesomeIcon icon={faTag} className="mx-2 icon-color" />
              Category
            </span>{" "}
            <span className="mx-3">
              <FontAwesomeIcon icon={faIndustry} className="mx-2 icon-color" />
              Industry
            </span>
          </p>
          <p className="ms-3 mt-1">
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore
            ducimus architecto accusantium, totam ratione eligendi incidunt
            tenetur officia, asperiores nisi nostrum et est praesentium
            doloribus exercitationem eos tempora recusandae fugit!
          </p>
          <a href="#" class="btn btn-primary position-relative translate-middle" style={{top:"90%",left:"85%", borderRadius:"0px"}}>Read More</a>
        </div>
      </div>
    </>
  );
}
