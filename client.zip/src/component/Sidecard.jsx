import React from "react";
import p1 from "./img/p1.jpg";
import p2 from './img/p2.jpg';
import p3 from './img/p3.jpg';
import p4 from "./img/p4.jpg";

export default function Sidecard() {
  return (
    <>
      <div class="row row-cols-1 row-cols-md-2 g-4 w-50">
        <div class="col">
          <div class="card">
            <img src={p1} class="card-img-top" alt="..." />

            <div class="carousel-caption d-none d-md-block" style={{backgroundColor:"#00000042", color:"white",fontWeight:"600"}}>
              <h5>First slide label</h5>
              <p>
                Some representative placeholder content for the first slide.
              </p>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card">
         
            <img src={p2} class="card-img-top" alt="..." />

            <div class="carousel-caption d-none d-md-block" style={{backgroundColor:"#00000042", color:"white",fontWeight:"600"}}>
              <h5>First slide label</h5>
              <p>
                Some representative placeholder content for the first slide.
              </p>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card">
            <img src={p3} class="card-img-top" alt="..." />

            <div class="carousel-caption d-none d-md-block" style={{backgroundColor:"#00000042", color:"white",fontWeight:"600"}}>
              <h5>First slide label</h5>
              <p>
                Some representative placeholder content for the first slide.
              </p>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card">
            <img src={p4} class="card-img-top" alt="..." />

            <div class="carousel-caption d-none d-md-block" style={{backgroundColor:"#00000042", color:"white",fontWeight:"600"}}>
              <h5>First slide label</h5>
              <p>
                Some representative placeholder content for the first slide.
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
