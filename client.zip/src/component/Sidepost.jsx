import React from "react";
import p2 from "./img/p2.jpg";
import p3 from "./img/p3.jpg";
import p4 from "./img/p4.jpg";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faCalendar,
  faTag,
  faIndustry
} from "@fortawesome/free-solid-svg-icons";

export default function Sidepost() {
  return (
    <>
      <div className="" style={{ width: "45%", marginLeft: "1rem" }}>
        <div class="card mb-3" style={{ maxWidth: "540px" }}>
          <div class="row g-0">
            <div class="col-md-4">
              <img src={p2} class="img-fluid rounded-start" alt="..." />
            </div>
            <div class="col-md-8">
              <div class="card-body">
                <h5 class="card-title">Card title</h5>

                <p class="card-text" style={{fontSize:"13px"}}>
                  <span className="mx-1">
                    <FontAwesomeIcon
                      icon={faCalendar}
                      className="mx-2 icon-color"
                    />
                    date
                  </span>{" "}
                  <span className="mx-1">
                    <FontAwesomeIcon icon={faTag} className="mx-2 icon-color" />
                    Category
                  </span>{" "}
                  <span className="mx-1">
                    <FontAwesomeIcon
                      icon={faIndustry}
                      className="mx-2 icon-color"
                    />
                    Industry
                  </span>
                </p>
              </div>
            </div>
          </div>
        </div>
        <div class="card mb-3" style={{ maxWidth: "540px" }}>
          <div class="row g-0">
            <div class="col-md-4">
              <img src={p3} class="img-fluid rounded-start" alt="..." />
            </div>
            <div class="col-md-8">
              <div class="card-body">
                <h5 class="card-title">Card title</h5>

                <p class="card-text" style={{fontSize:"13px"}}>
                  <span className="mx-1">
                    <FontAwesomeIcon
                      icon={faCalendar}
                      className="mx-2 icon-color"
                    />
                    date
                  </span>{" "}
                  <span className="mx-1">
                    <FontAwesomeIcon icon={faTag} className="mx-2 icon-color" />
                    Category
                  </span>{" "}
                  <span className="mx-1">
                    <FontAwesomeIcon
                      icon={faIndustry}
                      className="mx-2 icon-color"
                    />
                    Industry
                  </span>
                </p>
              </div>
            </div>
          </div>
        </div>
        <div class="card mb-3" style={{ maxWidth: "540px" }}>
          <div class="row g-0">
            <div class="col-md-4">
              <img src={p4} class="img-fluid rounded-start" alt="..." />
            </div>
            <div class="col-md-8">
              <div class="card-body">
                <h5 class="card-title">Card title</h5>

                <p class="card-text" style={{fontSize:"13px"}}>
                  <span className="mx-1">
                    <FontAwesomeIcon
                      icon={faCalendar}
                      className="mx-2 icon-color"
                    />
                    date
                  </span>{" "}
                  <span className="mx-1">
                    <FontAwesomeIcon icon={faTag} className="mx-2 icon-color" />
                    Category
                  </span>{" "}
                  <span className="mx-1">
                    <FontAwesomeIcon
                      icon={faIndustry}
                      className="mx-2 icon-color"
                    />
                    Industry
                  </span>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
