import React, { useState } from "react";

export default function Form() {
  const [conInput, setConInput] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    district: "",
    state: "",
    country: "",
    pincode: "",
    details: ""
  });

  // console.log(conInput);
  const handleChange = (event) => {
    const target = event.target;
    const value = target.value;
    const name = target.name;

    setConInput({
      ...conInput,
      [name]: value
    });
  };

  return (
    <>
      <div
        className="pt-3"
        style={{ backgroundColor: "#fbfbfb", borderRadius: "5px" }}
      >
        <form className="mx-auto" style={{ width: "90%" }}>
          <h3 style={{ textAlign: "center" }}>
            <span style={{ borderBottom: "3px solid skyblue" }}>
              Contact Form
            </span>
          </h3>
          Name:{" "}
          <input
            onChange={handleChange}
            type="text"
            name="name"
            value={conInput.name}
            className="form-control mb-2"
            placeholder="Enter Full Name"
            aria-label="Enter your name"
            aria-describedby="basic-addon1"
          />
          Phone No:
          <div className="input-group mb-2 ">
            <span className="input-group-text" id="basic-addon1">
              +91
            </span>
            <input
              onChange={handleChange}
              type="number"
              name="phone"
              value={conInput.phone}
              className="form-control"
              placeholder="Phone Number"
              aria-label="Phone Number"
              aria-describedby="basic-addon1"
            />
          </div>
          Email Id:
          <input
            onChange={handleChange}
            type="email"
            name="email"
            value={conInput.email}
            className="form-control mb-2"
            placeholder="Enter your email"
            aria-label="Enter your email"
            aria-describedby="basic-addon2"
          />
          Address:
          <input
            onChange={handleChange}
            type="text"
            name="address"
            value={conInput.address}
            className="form-control mb-2"
            placeholder="Address"
            aria-label="address"
            aria-describedby="basic-addon1"
          />
          City:
          <input
            onChange={handleChange}
            type="text"
            name="city"
            value={conInput.city}
            className="form-control mb-2"
            placeholder="City"
            aria-label="city"
            aria-describedby="basic-addon1"
          />
          District:
          <input
            onChange={handleChange}
            type="text"
            name="district"
            value={conInput.district}
            className="form-control mb-2"
            placeholder="District"
            aria-label="District"
            aria-describedby="basic-addon1"
          />
          Pin Code:
          <input
            onChange={handleChange}
            type="Number"
            name="pincode"
            value={conInput.pincode}
            className="form-control"
            placeholder="Pin Code"
            aria-label="Pin Code"
            aria-describedby="basic-addon1"
          />
          State:
          <div id="scrollspyHeading4" className="mb-2">
            <select
              className="form-select"
              aria-label="Default select example"
              name="state"
              onChange={handleChange}
              value={conInput.state}
            >
              <option value="state">Select State</option>
              <option value="west bangal">West Bangal</option>
              <option value="new delhi">New Delhi</option>
              <option value="goa">Goa</option>
            </select>
          </div>
          Country:
          <div id="scrollspyHeading4" className="mb-2">
            <select
              className="form-select"
              aria-label="Default select example"
              name="country"
              onChange={handleChange}
              value={conInput.country}
            >
              <option value="India">Select Country</option>
              <option value="India">India</option>

            </select>
          </div>
          <textarea
            className="mb-3"
            onChange={handleChange}
            name="details"
            id="additional"
            cols="120"
            rows="8"
            value={conInput.details}
            style={{ fontSize: "15px", border: "1px solid #e4e1e1" }}
          ></textarea>
          <button
            className="btn subbtn mx-auto mb-3"
            id="submit"
            style={{
              width: "99%",
              backgroundColor: "var(--orangeText)",
              color: "black",
              fontSize: "20px",
              border: "1px solid black"
            }}
            onClick=""
          >
            Submit
          </button>
        </form>
      </div>
    </>
  );
}
