import React, { useState } from "react";
import faceboook from "./img/facebook-f.svg";
import instagram from "./img/instagram.svg";
import youtube from "./img/youtube.svg";
import twitter from "./img/twitter.svg";

import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faUserGroup,
  faEyeLowVision,
  faBrain
} from "@fortawesome/free-solid-svg-icons";

export default function Subnavbar() {
  const [latestnews, setLatestnews] = useState("News");
  //

  return (
    <>
      <nav class="navbar bg-body-tertiary px-5">
        <div className=" ">
          Latest News: <a href="">{latestnews} </a>
        </div>
        <div class="d-flex" style={{width:"200px"}}>
          <a class="navbar-brand" href="/">
            <img src={faceboook} alt="facebook" style={{height:"25px"}} />
          </a>
          <a class="navbar-brand" href="/">
            <img src={twitter} alt="facebook" style={{height:"25px"}} />
          </a>
          <a class="navbar-brand" href="/">
            <img src={youtube} alt="facebook"  style={{height:"25px"}} />
          </a>
          <a class="navbar-brand" href="/">
            <img src={instagram} alt="facebook" style={{height:"25px"}} />
          </a>
        </div>
      </nav>
    </>
  );
}
